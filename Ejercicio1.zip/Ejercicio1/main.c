/*Solicita al usuario un numero y muestra la tabla de multiplicar del numero ingresado
El mensaje en pantalla "nx1=�?
*/
#include <stdio.h>
#include <stdlib.h>


int main() {
    int numeroUsuario;

    printf("Ingrese un numero: ");
    scanf("%d", &numeroUsuario);
    for (int i = 1; i <= 10; i++) {
        printf("%d x %d = %d\n", numeroUsuario, i, numeroUsuario * i);
    }

    return 0;
}
