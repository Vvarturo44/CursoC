/*
Realiza un programa en C que solicite un numero y de solucion a la siguiente sumatoria
(1 + (1/2)+ ... + ((1/n)) donde en es cualquier numero
*/

#include <stdio.h>
#include <stdlib.h>

int main() {
    int n;
    float suma = 0.0;
    printf("Ingrese un numero entero positivo (n): ");
    scanf("%d", &n);
    while (n <= 0) {
        printf("El numero debe ser positivo. Intente de nuevo: ");
        scanf("%d", &n);
    }
    printf("(");
    for (int i = 1; i <= n; i++) {
        printf("1/%d", i);
        if (i != n) {
            printf(" + ");
        }
    }
    printf(")\n");
    for (int i = 1; i <= n; i++) {
        suma += 1.0 / i;
    }
    printf("La sumatoria es: %.2f\n", suma);
    return 0;
}
