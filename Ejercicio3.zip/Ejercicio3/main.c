/*
Realiza un programa en C
Solicita al usuario dos numeros enteros, imprima la serie de los numeros intermedios y realice la suma de los dos numeros.
*/

#include <stdio.h>
#include <stdlib.h>

int main() {
    int a, b;
    int suma = 0;

    printf("Ingrese el primer numero entero: ");
    scanf("%d", &a);
    printf("Ingrese el segundo numero entero: ");
    scanf("%d", &b);

    if (a > b) {
        int temp = a;
        a = b;
        b = temp;
    }

    printf("Los numeros intermedios entre %d y %d son: ", a, b);
    for (int i = a + 1; i < b; i++) {
        printf("%d ", i);
    }


    suma = a + b;
    printf("\nLa suma de %d y %d es: %d\n", a, b, suma);

    return 0;
}
